<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

Dict::Add('EN US', 'English', 'English', array(
	// Dictionary entries go here
'Class:PC/Attribute:power_id' => 'Power Source',
'Class:PC/Attribute:brandmon_id' => 'Monitor Brand',
'Class:PC/Attribute:modelmon_id' => 'Monitor Model',
'Class:PC/Attribute:assetmon_number' => 'Monitor Asset',
));
?>
