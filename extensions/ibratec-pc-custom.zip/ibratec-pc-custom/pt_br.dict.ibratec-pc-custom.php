<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

Dict::Add('PT BR', 'Brazilian', 'Brazilian', array(
	// Dictionary entries go here
'Class:PC/Attribute:power_id' => 'Fonte de energia',
'Class:PC/Attribute:brandmon_id' => 'Fabricante do Monitor',
'Class:PC/Attribute:modelmon_id' => 'Modelo do Monitor',
'Class:PC/Attribute:assetmon_number' => 'Ativo do Monitor',
));
?>
